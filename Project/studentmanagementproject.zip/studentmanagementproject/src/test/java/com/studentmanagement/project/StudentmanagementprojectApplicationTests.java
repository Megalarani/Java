package com.studentmanagement.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentmanagementprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
