package com.studenttest;
import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.entity.Student;
import com.repository.StudentRepository;
import com.service.StudentService;
import com.studentmanagement.project.StudentmanagementprojectApplication;

@SpringBootTest(classes=StudentmanagementprojectApplication.class)
public class StudentTestService {
	@Autowired
	private StudentService studentservice;
	@MockBean
	private StudentRepository studentrepository;

	@Test
	void testSaveStudent() {
		Student student = new Student(0, null, null, null, 0, 0);
		student.setSname("aditya");
		student.setEmail("me@gmail.com");
		student.setCourse("java");
		student.setMarks(90);
		student.setPhoneno(987654321);
		Mockito.when(studentrepository.save(student)).thenReturn(student);
		assertThat(studentservice.createStudent(student)).isEqualTo("student details saved successfully");
	}
}


