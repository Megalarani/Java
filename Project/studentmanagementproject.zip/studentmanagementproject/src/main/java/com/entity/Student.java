package com.entity;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="student_details")
public class Student {
	  @Id
	  @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private int sid;
	  @Column(name = "sname")
	  private String sname;
	  @Column(name = "Email")
	  private String Email;
	  @Column(name = "course")
	  private String course;	
	  @Column(name = "marks")
	  private int marks;	
	  @Column(name = "phoneno")
	  private long phoneno;
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	public int getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
	public long getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(long phoneno) {
		this.phoneno = phoneno;
	}
	public Student(int sid, String sname, String email, String course, int marks, long phoneno) {
		super();
		this.sid = sid;
		this.sname = sname;
		Email = email;
		this.course = course;
		this.marks = marks;
		this.phoneno = phoneno;
	}
	@Override
	public String toString() {
		return "Student [sid=" + sid + ", sname=" + sname + ", Email=" + Email + ", course=" + course + ", marks="
				+ marks + ", phoneno=" + phoneno + "]";
	}	
	
}