package com.service;
import java.util.List;

import com.entity.Student;
public interface StudentService {
Student saveStudent(Student student);
List<Student> getAllStudents();
Student getStudentById(int id);
Student updateStudent(Student student, int id);
void deleteStudent(int id);
String createStudent(Student student);
}
