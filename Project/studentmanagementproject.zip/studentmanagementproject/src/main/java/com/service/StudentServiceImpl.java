package com.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.exception.ResourceNotFoundException;
import com.entity.Student;
import com.repository.StudentRepository;

@Service
public class StudentServiceImpl implements StudentService {
	@Autowired
	public StudentRepository studentrepository;
		private StudentRepository studentRepository;
		public StudentServiceImpl(StudentRepository studentRepository) {
		super();
		this.studentRepository = studentRepository;
		}
		@Override
		public Student saveStudent(Student student) {
		return studentRepository.save(student);
		}
		@Override
		public List<Student> getAllStudents() {
		return studentRepository.findAll();
		}
		@Override
		public Student getStudentById(int id) {
		

		return studentRepository.findById(id).orElseThrow(() ->

		new
		ResourceNotFoundException("Student", "Id", id));
		}
		@Override
		public String createStudent(Student student) {
			// String message = null;
			studentrepository.save(student);
			if (student != null) {
				return "student details saved successfully";
			}

			return "errorfound";
		}
		@Override
		public Student updateStudent(Student student, int id) {
	
		Student existingStudent =
		studentRepository.findById(id).orElseThrow(

		() -> new ResourceNotFoundException("Student","Id", id));

		existingStudent.setSname(student.getSname());
		existingStudent.setEmail(student.getEmail());
		existingStudent.setCourse(student.getCourse());
		existingStudent.setMarks(student.getMarks());
		existingStudent.setPhoneno(student.getPhoneno());
		
		studentRepository.save(existingStudent);
		return existingStudent;
		}
		@Override
		public void deleteStudent(int id) {
		
		studentRepository.findById(id).orElseThrow(() ->
		new
		ResourceNotFoundException("Student", "Id", id));
		studentRepository.deleteById(id);
		}


}
